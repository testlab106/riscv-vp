require_extension('D');
require_fp;
WRITE_FRD((FRS1 &~ INT64_MIN) | ((~FRS2) & INT64_MIN));
