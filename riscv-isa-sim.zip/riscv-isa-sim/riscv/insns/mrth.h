throw trap_illegal_instruction();
