require_extension('F');
require_fp;
WRITE_FRD(zext32(RS1));
