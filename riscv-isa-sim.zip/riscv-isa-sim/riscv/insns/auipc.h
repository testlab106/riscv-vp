WRITE_RD(sext_xlen(insn.u_imm() + pc));
