WRITE_RD(sreg_t(RS1) < sreg_t(RS2));
