WRITE_RD(sreg_t(RS1) < sreg_t(insn.i_imm()));
