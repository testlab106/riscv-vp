require_rvc;
require_xpr64;
CRD = mmu.load_int64(XPR[30]+CIMM6*8);
