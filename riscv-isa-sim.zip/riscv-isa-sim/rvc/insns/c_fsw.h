require_rvc;
require_fp;
mmu.store_uint32(CRS1S+CIMM5*4, FCRS2S);
