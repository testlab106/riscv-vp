require_rvc;
CRD = mmu.load_int32(CRS1);
