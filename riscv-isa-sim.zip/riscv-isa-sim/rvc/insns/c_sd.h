require_rvc;
require_xpr64;
mmu.store_uint64(CRS1S+CIMM5*8, CRS2S);
